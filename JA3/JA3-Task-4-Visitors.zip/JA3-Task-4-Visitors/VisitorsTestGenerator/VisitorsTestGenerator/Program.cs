﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisitorsTestGenerator
{
    static class RandomExtensions
    {
        public static T Next<T>(this Random thiz, IList<T> c)
        {
            return c[thiz.Next(0, c.Count)];
        }
    }

    class Program
    {
        class Reg
        {
            public string id;
            public int age;
            public string name;

            public Reg(string id, int age, string name)
            {
                this.id = id;
                this.age = age;
                this.name = name;
            }

            public override bool Equals(object obj)
            {
                return this.id.Equals((obj as Reg).id);
            }

            public override int GetHashCode()
            {
                return this.id.GetHashCode();
            }

            public override string ToString()
            {
                return "entry " + this.id + " " + this.name + " " + this.age;
            }
        }

        static Random rand = new Random();

        static void Main(string[] args)
        {
            generateTest("test.001", 3, 17, 10, new List<string>(){ "age" });
            generateTest("test.002", 100, 200, 30, new List<string>() { "age" });
            generateTest("test.003", 400, 900, 10, new List<string>() { "name" });
            generateTest("test.004", 400, 440, 30, new List<string>() { "name" });
            generateTest("test.005", 400, 600, 100, new List<string>() { "name", "age" });

            generateTest("test.006", 1000, 5000, 5000, new List<string>() { "age", "name", "name", "name" });
            generateTest("test.007", 2000, 6000, 6000, new List<string>() { "age", "age", "age", "name" });
            generateTest("test.008", 3000, 7000, 7000, new List<string>() { "age" });
            generateTest("test.009", 4000, 8000, 8000, new List<string>() { "name" });
            generateTest("test.010", 5000, 9000, 9000, new List<string>() { "age", "name" });
        }

        static void generateTest(string testName, int uniqueRegsCount, int totalRegsCount, int queriesCount, List<string> queries)
        {
            HashSet<Reg> uniqueRegs = new HashSet<Reg>();
            while(uniqueRegs.Count < uniqueRegsCount)
            {
                uniqueRegs.Add(new Reg(getRandomId(), getRandomAge(), getRandomName()));
            }

            List<Reg> allRegs = new List<Reg>(uniqueRegs);
            while (allRegs.Count < totalRegsCount)
            {
                allRegs.Add(rand.Next(allRegs));
            }

            StringBuilder input = new StringBuilder();
            StringBuilder output = new StringBuilder();

            HashSet<Reg> currentRegs = new HashSet<Reg>();
            int regIndex = 0;
            int currentQueries = 0;
            while (currentQueries < queriesCount && regIndex < allRegs.Count)
            {
                if (regIndex < allRegs.Count)
                {
                    int regsBeforeQuery = rand.Next(0, 10);
                    for (int i = regIndex; i < regIndex + regsBeforeQuery && i < allRegs.Count; i++)
                    {
                        currentRegs.Add(allRegs[i]);
                        input.AppendLine(allRegs[i].ToString());
                    }

                    regIndex += regsBeforeQuery;
                }

                if (currentQueries < queriesCount)
                {
                    switch (rand.Next(queries))
                    {
                        case "age":
                            int startAge = 0;
                            int endAge = 0;
                            while (startAge >= endAge)
                            {
                                startAge = getRandomAge();
                                endAge = getRandomAge();
                            }

                            input.AppendLine("age " + startAge + " " + endAge);
                            output.AppendLine(currentRegs.Count(r => r.age >= startAge && r.age < endAge) + "");

                            break;
                        case "name":
                            string name = getRandomName();
                            input.AppendLine("name " + name);
                            output.AppendLine(currentRegs.Count(r => r.name == name) + "");

                            break;
                    }

                    currentQueries++;
                }
            }

            input.AppendLine("end");

            System.IO.File.WriteAllText(testName + ".in.txt", input.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", output.ToString());
        }

        static string getRandomId()
        {
            return rand.Next(1, 100000).ToString("X");
        }

        static string getRandomName()
        {
            return names[rand.Next(0, names.Length)];
        }

        static int getRandomAge()
        {
            return rand.Next(1, 100);
        }

        static string[] names =
        {
            "Oxalis",
            "Eggy",
            "Hamilton",
            "Promethia",
            "Severus",
            "Numerian",
            "Flakee",
            "Canna",
            "Theodosius",
            "Jerky",
            "Reuben",
            "Yttria",
            "Mickey",
            "Romulus",
            "Bryce",
            "Probus",
            "Hadrian",
            "Marcian",
            "MoonPie",
            "Yellow",
            "Psoralea",
            "Zino",
            "Cabbage",
            "Nelson",
            "Hamms",
            "Carus",
            "Weiner",
            "Puffin",
            "Chip",
            "Marcrinus"
        };
    }
}
