#ifndef POPULATIONS_H
#define POPULATIONS_H

#include <cstddef>

extern const size_t NumPopulations;
size_t * getPopulationsSorted();

#endif // POPULATIONS_H
