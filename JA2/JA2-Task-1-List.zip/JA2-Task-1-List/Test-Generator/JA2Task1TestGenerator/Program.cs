﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JA2Task1TestGenerator
{
    class Program
    {
        static Random rand = new Random();

        const int MaxSingleCount = 100;

        static void Main(string[] args)
        {
            generateTest("test.001", 10);
            generateTest("test.002", 200);
            generateTest("test.003", 1300);
            generateTest("test.004", 2000);
            generateTest("test.005", 4200);
            generateTest("test.006", 6900);
            generateTest("test.007", 8000);
            generateTest("test.008", 8000);
            generateTest("test.009", 10000);
            generateTest("test.010", 10000);
        }

        private static void generateTest(string testName, int totalCount)
        {
            List<int> generated = new List<int>();

            while (generated.Count < totalCount)
            {
                generated.Add(rand.Next(-9999, 10000));
            }

            StringBuilder inputBuilder = new StringBuilder();

            int lastIndex = 0;
            for (int i = rand.Next(1, Math.Min(generated.Count, MaxSingleCount)); lastIndex < generated.Count; i += rand.Next(1, Math.Min(generated.Count, MaxSingleCount)))
            {
                List<int> sortedSublist = generated.GetRange(lastIndex, Math.Min(i, generated.Count) - lastIndex);
                sortedSublist.Sort();

                inputBuilder.AppendLine(String.Join(" ", sortedSublist));

                lastIndex = i;
            }
            
            inputBuilder.AppendLine("end");
            inputBuilder.AppendLine();

            generated.Sort();

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", String.Join(" ", generated));
        }
    }
}
