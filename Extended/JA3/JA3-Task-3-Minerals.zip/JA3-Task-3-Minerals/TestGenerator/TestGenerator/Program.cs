﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestGenerator
{
    class Program
    {
        const int MaxX = 1000;
        const int MaxY = 1000;
        static Random rand = new Random();

        class Pos
        {
            public int x, y;

            public Pos(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public int ManhattanDistance(Pos other)
            {
                return Math.Abs(this.x - other.x) + Math.Abs(this.y - other.y);
            }

            public override string ToString()
            {
                return this.x + " " + this.y;
            }
        }

        static void Main(string[] args)
        {
            generateTest("test.001", 1, 2);
            generateTest("test.002", 10, 20);
            generateTest("test.003", 7, 100);
            generateTest("test.004", 30, 200);

            generateTest("test.005", 100, 100000);
            generateTest("test.006", 1000, 100000);
            generateTest("test.007", 300, 400000);
            generateTest("test.008", 4000, 400000);
            generateTest("test.009", 400, 500000);
            generateTest("test.010", 5000, 500000);
        }

        static void generateTest(string testName, int mineralsNeeded, int mineralsCount)
        {
            checked
            {
                bool[,] used = new bool[MaxX, MaxY];

                List<Pos> minerals = new List<Pos>();

                while (minerals.Count < mineralsCount)
                {
                    minerals.Add(generateRandomUniquePos(used));
                }

                Pos center = generateRandomUniquePos(used);
                List<Pos> closest = findClosest(mineralsNeeded, center, minerals);

                int timeNeeded = closest.Sum((p) => p.ManhattanDistance(center)) * 2;

                StringBuilder inputBuilder = new StringBuilder();
                inputBuilder.AppendLine(mineralsNeeded.ToString());
                inputBuilder.AppendLine(center.ToString());
                inputBuilder.AppendLine(mineralsCount.ToString());
                foreach (var m in minerals)
                {
                    inputBuilder.AppendLine(m.ToString());
                }

                System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
                System.IO.File.WriteAllText(testName + ".out.txt", timeNeeded.ToString());
            }
        }

        static List<Pos> findClosest(int count, Pos center, List<Pos> all)
        {
            all = new List<Pos>(all);
            List<Pos> result = new List<Pos>();

            while (result.Count < count)
            {
                Pos closest = all[0];
                int minDist = center.ManhattanDistance(closest);
                foreach (var p in all)
                {
                    int d = center.ManhattanDistance(p);
                    if (d < minDist)
                    {
                        minDist = d;
                        closest = p;
                    }
                }

                result.Add(closest);
                all.Remove(closest);
            }

            return result;
        }

        private static Pos generateRandomUniquePos(bool[,] used)
        {
            checked
            {
                int x, y;
                do
                {
                    x = rand.Next(0, MaxX);
                    y = rand.Next(0, MaxY);
                } while (used[x, y]);
                Pos p = new Pos(x, y);
                used[p.x, p.y] = true;
                return p;
            }
        }
    }
}
